import random

items = {}


def get_random_item() -> int:
    # Getting a random phrase
    return random.choice(list(items.values()))


def add_item(phrase):
    # Adding a phrase
    id = len(items) + 1
    phrase.update({"id": id})
    items[id] = phrase
    return phrase


def delete_item(id: int) -> None:
    # Deleting a phrase
    if id in items:
        del items[id]
    else:
        raise ValueError("Phrase doesn't exist")
