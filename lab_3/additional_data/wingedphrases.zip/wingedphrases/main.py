from fastapi import FastAPI
from fastapi import HTTPException
from db import get_random_item, add_item, delete_item


app = FastAPI(title="Random phrase")

@app.get("/")
def root():
    return {"message": "Hello World"}


@app.get(
    "/get",
    response_description="Random phrase",
    description="Get random phrase from database"
)
def get():
    try:
        phrase = get_random_item()
    except IndexError:
        raise HTTPException(404, "Phrase list is empty")
    return phrase


@app.post(
    "/add",
    response_description="Added phrase with *id* parameter"
)
def add(phrase: dict):
    phrase_out = add_item(phrase)
    return phrase_out

@app.delete("/delete", response_description="Result of deletion")
def delete(id: int):
    try:
        delete_item(id)
        return {"message": "OK"}
    except ValueError as e:
        raise HTTPException(404, str(e))
